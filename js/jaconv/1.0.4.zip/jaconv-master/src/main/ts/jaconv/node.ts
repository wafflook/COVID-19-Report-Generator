//---------------------------------------------------------------------
// node 
//

namespace jaconv {
  // export
  declare var exports : any;
  declare var module : any;
  if (typeof exports === 'object') {
    module.exports = jaconv;
  }
}
