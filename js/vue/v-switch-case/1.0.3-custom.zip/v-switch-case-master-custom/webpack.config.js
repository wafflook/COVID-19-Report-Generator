const webpack = require('webpack')
const merge = require('webpack-merge')
const path = require('path')

const commonConfig = {
  output: {
    path: path.resolve(__dirname, 'dist'),
  },
  module: {
    rules: [
      { 
        test: /\.js$/,
        loader: 'babel-loader',
        include: __dirname,
        exclude: /node_modules/,
        options: {
          babelrc: false
        }
      }
    ]
  },
  optimization: {
    minimize: true
  }
}


module.exports = [
  // browser
  merge(commonConfig, {
    entry: path.resolve(__dirname, 'plugin.js'),
    output: {
      filename: 'v-switch.js',
      libraryTarget: 'window',
      library: 'VueSwitch'
    },
    optimization: {
      minimize: false
    }
  }),

  // browser minify
  merge(commonConfig, {
    entry: path.resolve(__dirname, 'plugin.js'),
    output: {
      filename: 'v-switch.min.js',
      libraryTarget: 'window',
      library: 'VueSwitch'
    },
    optimization: {
      minimize: true
    }
  })
]
