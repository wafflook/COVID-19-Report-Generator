<template>
  <div>
    <portal to="title">Page A</portal>
    <p>The contents of Page A.</p>
  </div>
</template>
