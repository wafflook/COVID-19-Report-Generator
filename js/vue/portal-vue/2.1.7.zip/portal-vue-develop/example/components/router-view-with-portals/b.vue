<template>
  <div>
    <portal to="title">Page B</portal>
    <p>The contents of Page B.</p>
  </div>
</template>
