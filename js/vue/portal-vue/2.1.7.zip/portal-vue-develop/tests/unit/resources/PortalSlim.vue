<template>
  <div>
    <portal ref="portal" to="target" disabled :slim="true">
      <p>Test</p>
    </portal>
  </div>
</template>
<script>
export default {
  created() {},
}
</script>
