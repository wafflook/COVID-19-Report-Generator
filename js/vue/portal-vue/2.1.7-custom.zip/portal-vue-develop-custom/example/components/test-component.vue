<template>
  <div class="">Hello from TestComponent!</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'TestComponent',
})
</script>
