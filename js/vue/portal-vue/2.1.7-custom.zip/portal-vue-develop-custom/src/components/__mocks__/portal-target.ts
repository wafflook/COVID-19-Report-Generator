module.exports = {
  render(h: any) {
    return h('div')
  },
  props: ['name', 'id', 'tag'],
}
