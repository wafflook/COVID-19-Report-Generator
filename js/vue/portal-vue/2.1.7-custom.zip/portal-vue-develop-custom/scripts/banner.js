module.exports = version => `
 /*! 
  * portal-vue © Thorsten Lünborg, ${new Date().getFullYear()} 
  * 
  * Version: ${version}
  * 
  * LICENCE: MIT 
  * 
  * https://github.com/linusborg/portal-vue
  * 
 */
`
