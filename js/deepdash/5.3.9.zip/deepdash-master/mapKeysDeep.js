'use strict';

var getMapKeysDeep = require('./getMapKeysDeep.js');
var mapKeysDeep$1 = require('./deps/mapKeysDeep.js');

/* build/tpl */
var mapKeysDeep = getMapKeysDeep(mapKeysDeep$1);

module.exports = mapKeysDeep;
