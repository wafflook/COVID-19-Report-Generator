'use strict';

var getMapValuesDeep = require('./getMapValuesDeep.js');
var mapValuesDeep$1 = require('./deps/mapValuesDeep.js');

/* build/tpl */
var mapValuesDeep = getMapValuesDeep(mapValuesDeep$1);

module.exports = mapValuesDeep;
