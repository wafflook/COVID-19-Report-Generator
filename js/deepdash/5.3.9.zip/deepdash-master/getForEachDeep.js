'use strict';

var getEachDeep = require('./getEachDeep.js');

function getForEachDeep(_) {
  return getEachDeep(_);
}

module.exports = getForEachDeep;
