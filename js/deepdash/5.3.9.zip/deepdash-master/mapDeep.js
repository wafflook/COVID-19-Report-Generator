'use strict';

var getMapDeep = require('./getMapDeep.js');
var mapDeep$1 = require('./deps/mapDeep.js');

/* build/tpl */
var mapDeep = getMapDeep(mapDeep$1);

module.exports = mapDeep;
