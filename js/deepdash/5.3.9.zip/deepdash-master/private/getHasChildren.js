// 'use strict';

// function getHasChildren(_) {
//   function hasChildren(obj, childrenPath) {
//     return _.some(childrenPath, function (cp) {
//       var children = _.get(obj, cp);
//       return !_.isEmpty(children);
//     });
//   }
//   return hasChildren;
// }

// module.exports = getHasChildren;
