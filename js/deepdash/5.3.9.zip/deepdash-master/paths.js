'use strict';

var getPaths = require('./getPaths.js');
var paths$1 = require('./deps/paths.js');

/* build/tpl */
var paths = getPaths(paths$1);

module.exports = paths;
