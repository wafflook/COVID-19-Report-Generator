'use strict';

var getPathToString = require('./getPathToString.js');
var pathToString$1 = require('./deps/pathToString.js');

/* build/tpl */
var pathToString = getPathToString(pathToString$1);

module.exports = pathToString;
