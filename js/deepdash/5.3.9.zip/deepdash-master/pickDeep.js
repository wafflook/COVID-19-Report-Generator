'use strict';

var getPickDeep = require('./getPickDeep.js');
var pickDeep$1 = require('./deps/pickDeep.js');

/* build/tpl */
var pickDeep = getPickDeep(pickDeep$1);

module.exports = pickDeep;
