'use strict';

var getCondense = require('./getCondense.js');

/* build/tpl */
var condense = getCondense();

module.exports = condense;
