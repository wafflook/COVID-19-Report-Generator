'use strict';

var getCondenseDeep = require('./getCondenseDeep.js');
var condenseDeep$1 = require('./deps/condenseDeep.js');

/* build/tpl */
var condenseDeep = getCondenseDeep(condenseDeep$1);

module.exports = condenseDeep;
