'use strict';

var getExists = require('./getExists.js');
var exists$1 = require('./deps/exists.js');

/* build/tpl */
var exists = getExists(exists$1);

module.exports = exists;
