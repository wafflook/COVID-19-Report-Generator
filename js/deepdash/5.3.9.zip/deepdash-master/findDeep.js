'use strict';

var getFindDeep = require('./getFindDeep.js');
var findDeep$1 = require('./deps/findDeep.js');

/* build/tpl */
var findDeep = getFindDeep(findDeep$1);

module.exports = findDeep;
