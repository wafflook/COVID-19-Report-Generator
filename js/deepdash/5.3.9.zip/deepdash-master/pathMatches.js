'use strict';

var getPathMatches = require('./getPathMatches.js');
var pathMatches$1 = require('./deps/pathMatches.js');

/* build/tpl */
var pathMatches = getPathMatches(pathMatches$1);

module.exports = pathMatches;
