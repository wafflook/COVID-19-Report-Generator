// const _ = require('../deepdash')(require('lodash'));
// let obj = {
//   good1: true,
//   bad1: false,
//   good2: { good3: true, bad3: true },
//   bad2: { good: true },
//   good4: [{ good5: true, bad5: true }],
//   bad4: [],
// };
// let clean = _.pickDeep(obj, /\.?good\d*$/);
// console.log(clean);
