'use strict';
const obj = require('lodash');

module.exports = require('../test/object');
