'use strict';

var getFilterDeep = require('./getFilterDeep.js');
var filterDeep$1 = require('./deps/filterDeep.js');

/* build/tpl */
var filterDeep = getFilterDeep(filterDeep$1);

module.exports = filterDeep;
