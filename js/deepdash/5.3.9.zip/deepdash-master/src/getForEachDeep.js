import getEachDeep from './getEachDeep.js';

export default function getForEachDeep(_) {
  return getEachDeep(_);
}
