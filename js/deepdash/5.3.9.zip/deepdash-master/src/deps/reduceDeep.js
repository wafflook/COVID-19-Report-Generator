import eachDeepDeps from './eachDeep.js';

export default eachDeepDeps;
