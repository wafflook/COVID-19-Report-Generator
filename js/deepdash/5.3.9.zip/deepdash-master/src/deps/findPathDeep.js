import findDeep from './findDeep.js';
export default findDeep;
