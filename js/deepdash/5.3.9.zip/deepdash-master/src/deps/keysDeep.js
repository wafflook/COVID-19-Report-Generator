import deps from './paths.js';
export default deps;
