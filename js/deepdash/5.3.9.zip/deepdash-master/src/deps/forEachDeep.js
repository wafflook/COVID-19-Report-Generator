import deps from './eachDeep.js';
export default deps;
