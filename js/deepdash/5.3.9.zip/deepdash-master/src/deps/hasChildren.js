import _some from 'lodash-es/some.js';
import _get from 'lodash-es/get.js';
import _isEmpty from 'lodash-es/isEmpty.js';

var deps = {
  some: _some,
  get: _get,
  isEmpty: _isEmpty,
};

export default deps;
