import _isString from 'lodash-es/isString.js';
import _reduce from 'lodash-es/reduce.js';

var deps = {
  isString: _isString,
  reduce: _reduce,
};

export default deps;
