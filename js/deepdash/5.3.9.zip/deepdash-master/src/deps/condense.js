var deps = {};

export default deps;
