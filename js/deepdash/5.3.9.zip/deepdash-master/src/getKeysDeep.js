import getPaths from './getPaths.js';

export default function getKeysDeep(_) {
  return getPaths(_);
}
