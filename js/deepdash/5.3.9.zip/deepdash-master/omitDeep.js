'use strict';

var getOmitDeep = require('./getOmitDeep.js');
var omitDeep$1 = require('./deps/omitDeep.js');

/* build/tpl */
var omitDeep = getOmitDeep(omitDeep$1);

module.exports = omitDeep;
