/* build/tpl */
import mapValuesDeep from "./mapValuesDeep";

export default function getMapValuesDeep(_: Object): typeof mapValuesDeep;

