/* build/tpl */
import condenseDeep from "./condenseDeep";

export default function getCondenseDeep(_: Object): typeof condenseDeep;

