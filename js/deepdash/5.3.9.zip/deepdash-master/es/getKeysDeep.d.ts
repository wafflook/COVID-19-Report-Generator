/* build/tpl */
import keysDeep from "./keysDeep";

export default function getKeysDeep(_: Object): typeof keysDeep;

