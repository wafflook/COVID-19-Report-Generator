/* build/tpl */
import omitDeep from "./omitDeep";

export default function getOmitDeep(_: Object): typeof omitDeep;

