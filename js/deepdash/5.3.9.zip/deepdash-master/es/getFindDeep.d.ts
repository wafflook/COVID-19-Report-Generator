/* build/tpl */
import findDeep from "./findDeep";

export default function getFindDeep(_: Object): typeof findDeep;

