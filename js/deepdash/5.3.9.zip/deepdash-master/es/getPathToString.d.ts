/* build/tpl */
import pathToString from "./pathToString";

export default function getPathToString(_: Object): typeof pathToString;

