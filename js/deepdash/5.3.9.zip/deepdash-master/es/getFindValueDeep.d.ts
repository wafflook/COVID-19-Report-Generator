/* build/tpl */
import findValueDeep from "./findValueDeep";

export default function getFindValueDeep(_: Object): typeof findValueDeep;

