/* build/tpl */
import paths from "./paths";

export default function getPaths(_: Object): typeof paths;

