/* build/tpl */
import forEachDeep from "./forEachDeep";

export default function getForEachDeep(_: Object): typeof forEachDeep;

