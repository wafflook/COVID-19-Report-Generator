import { Path } from "./Path";

export default function exists(obj: any, path: Path): boolean;
