/* build/tpl */
import mapKeysDeep from "./mapKeysDeep";

export default function getMapKeysDeep(_: Object): typeof mapKeysDeep;

