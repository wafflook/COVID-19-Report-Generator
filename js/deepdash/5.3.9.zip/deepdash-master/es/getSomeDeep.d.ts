/* build/tpl */
import someDeep from "./someDeep";

export default function getSomeDeep(_: Object): typeof someDeep;

