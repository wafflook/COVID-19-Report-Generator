export default function condense(
  arr: any[]
): any[];
