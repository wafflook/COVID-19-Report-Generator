/* build/tpl */
import findPathDeep from "./findPathDeep";

export default function getFindPathDeep(_: Object): typeof findPathDeep;

