/* build/tpl */
import index from "./index";

export default function getIndex(_: Object): typeof index;

