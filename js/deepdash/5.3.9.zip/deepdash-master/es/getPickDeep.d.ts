/* build/tpl */
import pickDeep from "./pickDeep";

export default function getPickDeep(_: Object): typeof pickDeep;

