/* build/tpl */
import pathMatches from "./pathMatches";

export default function getPathMatches(_: Object): typeof pathMatches;

