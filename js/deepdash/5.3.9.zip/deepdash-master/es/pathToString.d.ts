export default function pathToString(
  path: (string | number)[],
  ...prefixes: string[]
): string;
