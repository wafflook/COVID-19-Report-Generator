/* build/tpl */
import reduceDeep from "./reduceDeep";

export default function getReduceDeep(_: Object): typeof reduceDeep;

