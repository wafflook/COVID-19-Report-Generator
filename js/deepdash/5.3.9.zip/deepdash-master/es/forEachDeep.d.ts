import forEachDeep from "./eachDeep";
export default forEachDeep;
