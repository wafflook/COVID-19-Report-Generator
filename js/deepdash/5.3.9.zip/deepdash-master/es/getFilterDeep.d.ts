/* build/tpl */
import filterDeep from "./filterDeep";

export default function getFilterDeep(_: Object): typeof filterDeep;

