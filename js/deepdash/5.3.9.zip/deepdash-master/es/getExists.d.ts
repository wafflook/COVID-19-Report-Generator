/* build/tpl */
import exists from "./exists";

export default function getExists(_: Object): typeof exists;

