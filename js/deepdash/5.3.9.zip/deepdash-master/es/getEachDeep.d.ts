/* build/tpl */
import eachDeep from "./eachDeep";

export default function getEachDeep(_: Object): typeof eachDeep;

