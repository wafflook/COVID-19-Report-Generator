/* build/tpl */
import condense from "./condense";

export default function getCondense(_: Object): typeof condense;

