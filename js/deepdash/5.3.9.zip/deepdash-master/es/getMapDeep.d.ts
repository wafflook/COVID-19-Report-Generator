/* build/tpl */
import mapDeep from "./mapDeep";

export default function getMapDeep(_: Object): typeof mapDeep;

