export type Path = (string | number)[] | string;
