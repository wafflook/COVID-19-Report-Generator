'use strict';

var paths = require('./paths.js');



module.exports = paths;
