'use strict';

var findDeep = require('./findDeep.js');



module.exports = findDeep;
