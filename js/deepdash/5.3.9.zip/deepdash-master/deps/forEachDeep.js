'use strict';

var eachDeep = require('./eachDeep.js');



module.exports = eachDeep;
