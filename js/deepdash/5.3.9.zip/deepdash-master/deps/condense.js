'use strict';

var deps = {};

module.exports = deps;
