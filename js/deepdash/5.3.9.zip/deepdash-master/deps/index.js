'use strict';

var _merge = require('lodash/merge.js');
var eachDeep = require('./eachDeep.js');

var deps = _merge({ merge: _merge }, eachDeep);

module.exports = deps;
