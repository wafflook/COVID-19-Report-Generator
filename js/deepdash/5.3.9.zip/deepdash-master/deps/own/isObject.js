'use strict';

var isObject = require('lodash/isObject');



module.exports = isObject;
