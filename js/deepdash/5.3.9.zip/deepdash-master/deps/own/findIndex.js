'use strict';

var findIndex = Array.prototype.findIndex;

module.exports = findIndex;
