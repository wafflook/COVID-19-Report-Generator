'use strict';

var _isArray = Array.isArray;

module.exports = _isArray;
