'use strict';

var getEachDeep = require('./getEachDeep.js');
var eachDeep$1 = require('./deps/eachDeep.js');

/* build/tpl */
var eachDeep = getEachDeep(eachDeep$1);

module.exports = eachDeep;
