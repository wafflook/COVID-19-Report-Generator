'use strict';

var getIndex = require('./getIndex.js');
var index$1 = require('./deps/index.js');

/* build/tpl */
var index = getIndex(index$1);

module.exports = index;
