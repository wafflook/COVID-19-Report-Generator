# autoKana2
JavaScriptでフリガナ取得

Blogの方に書いてあるので、そっち参照で。(^_^;)

http://pinch-blog.blogspot.jp/2016/12/compositionevent2.html
