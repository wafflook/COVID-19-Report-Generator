import document from "./document.js";

export default document.documentElement;
