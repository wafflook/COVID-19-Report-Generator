define(function () { 'use strict';

var nonce = { guid: Date.now() };

return nonce;

});
