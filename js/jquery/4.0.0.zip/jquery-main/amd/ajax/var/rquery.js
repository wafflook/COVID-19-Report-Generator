define(function () { 'use strict';

var rquery = ( /\?/ );

return rquery;

});
