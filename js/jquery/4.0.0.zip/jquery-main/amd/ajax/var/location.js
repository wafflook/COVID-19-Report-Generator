define(function () { 'use strict';

var location = window.location;

return location;

});
