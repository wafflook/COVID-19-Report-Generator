define(function () { 'use strict';

var cssExpand = [ "Top", "Right", "Bottom", "Left" ];

return cssExpand;

});
