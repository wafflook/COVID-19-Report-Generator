define(['./core', './selector', './traversing', './callbacks', './deferred', './deferred/exceptionHook', './core/ready', './data', './queue', './css/showHide', './event', './manipulation', './css', './effects', './queue/delay', './attributes/attr', './attributes/prop', './attributes/classes', './attributes/val', './event/trigger', './core/parseXML', './serialize', './ajax', './manipulation/_evalUrl', './wrap', './css/hiddenVisibleSelectors', './ajax/xhr', './ajax/script', './ajax/jsonp', './core/parseHTML', './ajax/load', './effects/animatedSelector', './offset', './dimensions', './deprecated', './exports/amd', './exports/global'], function (core, selector, traversing, callbacks, deferred, exceptionHook, ready, data, queue, showHide, event, manipulation, css, effects, delay, attr, prop, classes, val, trigger, parseXML, serialize, ajax, _evalUrl, wrap, hiddenVisibleSelectors, xhr, script, jsonp, parseHTML, load, animatedSelector, offset, dimensions, deprecated, amd, global) { 'use strict';



return core;

});
