define(['./document'], function (document) { 'use strict';

var documentElement = document.documentElement;

return documentElement;

});
