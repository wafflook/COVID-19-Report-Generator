define(['./class2type'], function (class2type) { 'use strict';

var toString = class2type.toString;

return toString;

});
