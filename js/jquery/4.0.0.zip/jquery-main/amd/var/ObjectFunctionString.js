define(['./fnToString'], function (fnToString) { 'use strict';

var ObjectFunctionString = fnToString.call( Object );

return ObjectFunctionString;

});
