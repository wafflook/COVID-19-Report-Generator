define(['./hasOwn'], function (hasOwn) { 'use strict';

var fnToString = hasOwn.toString;

return fnToString;

});
