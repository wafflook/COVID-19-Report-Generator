define(function () { 'use strict';

var getProto = Object.getPrototypeOf;

return getProto;

});
