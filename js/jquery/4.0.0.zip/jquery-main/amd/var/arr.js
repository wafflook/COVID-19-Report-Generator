define(function () { 'use strict';

var arr = [];

return arr;

});
