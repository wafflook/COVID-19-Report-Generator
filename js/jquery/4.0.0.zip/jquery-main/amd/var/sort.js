define(['./arr'], function (arr) { 'use strict';

var sort = arr.sort;

return sort;

});
