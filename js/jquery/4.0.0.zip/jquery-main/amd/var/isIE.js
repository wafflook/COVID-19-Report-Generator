define(['./document'], function (document) { 'use strict';

var isIE = document.documentMode;

return isIE;

});
