define(function () { 'use strict';

// All support tests are defined in their respective modules.
var support = {};

return support;

});
