define(['./arr'], function (arr) { 'use strict';

var pop = arr.pop;

return pop;

});
