define(function () { 'use strict';

// [[Class]] -> type pairs
var class2type = {};

return class2type;

});
