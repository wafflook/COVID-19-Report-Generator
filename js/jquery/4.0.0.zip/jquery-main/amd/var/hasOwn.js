define(['./class2type'], function (class2type) { 'use strict';

var hasOwn = class2type.hasOwnProperty;

return hasOwn;

});
