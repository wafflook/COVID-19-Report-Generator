define(['./arr'], function (arr) { 'use strict';

var push = arr.push;

return push;

});
