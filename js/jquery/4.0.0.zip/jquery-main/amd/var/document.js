define(function () { 'use strict';

var document = window.document;

return document;

});
