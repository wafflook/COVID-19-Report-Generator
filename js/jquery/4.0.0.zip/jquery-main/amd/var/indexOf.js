define(['./arr'], function (arr) { 'use strict';

var indexOf = arr.indexOf;

return indexOf;

});
