define(function () { 'use strict';

var rcheckableType = ( /^(?:checkbox|radio)$/i );

return rcheckableType;

});
