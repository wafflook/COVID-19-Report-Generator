define(['./arr'], function (arr) { 'use strict';

var slice = arr.slice;

return slice;

});
