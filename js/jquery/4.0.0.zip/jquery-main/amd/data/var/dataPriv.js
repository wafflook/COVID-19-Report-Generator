define(['../Data'], function (Data) { 'use strict';

var dataPriv = new Data();

return dataPriv;

});
