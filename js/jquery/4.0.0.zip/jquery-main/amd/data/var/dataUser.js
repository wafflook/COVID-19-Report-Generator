define(['../Data'], function (Data) { 'use strict';

var dataUser = new Data();

return dataUser;

});
