define(['../../core', '../../selector'], function (core, selector) { 'use strict';

var rneedsContext = core.expr.match.needsContext;

return rneedsContext;

});
