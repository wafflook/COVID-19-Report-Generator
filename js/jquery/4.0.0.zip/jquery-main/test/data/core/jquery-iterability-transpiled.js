function _createForOfIteratorHelper(o, allowArrayLike) {var it;if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) {if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {if (it) o = it;var i = 0;var F = function () {};return { s: F, n: function () {if (i >= o.length) return { done: true };return { done: false, value: o[i++] };}, e: function (e) {throw e;}, f: F };}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");}var normalCompletion = true,didErr = false,err;return { s: function () {it = o[Symbol.iterator]();}, n: function () {var step = it.next();normalCompletion = step.done;return step;}, e: function (e) {didErr = true;err = e;}, f: function () {try {if (!normalCompletion && it.return != null) it.return();} finally {if (didErr) throw err;}} };}function _unsupportedIterableToArray(o, minLen) {if (!o) return;if (typeof o === "string") return _arrayLikeToArray(o, minLen);var n = Object.prototype.toString.call(o).slice(8, -1);if (n === "Object" && o.constructor) n = o.constructor.name;if (n === "Map" || n === "Set") return Array.from(o);if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);}function _arrayLikeToArray(arr, len) {if (len == null || len > arr.length) len = arr.length;for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];return arr2;} /* global startIframeTest */

jQuery(function () {
  "use strict";

  var elem = jQuery("<div></div><span></span><a></a>");
  var result = "";
  var i;var _iterator = _createForOfIteratorHelper(
  elem),_step;try {for (_iterator.s(); !(_step = _iterator.n()).done;) {i = _step.value;
      result += i.nodeName;
    }} catch (err) {_iterator.e(err);} finally {_iterator.f();}

  startIframeTest(result);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImpxdWVyeS1pdGVyYWJpbGl0eS10cmFuc3BpbGVkLWVzNi5qcyJdLCJuYW1lcyI6WyJqUXVlcnkiLCJlbGVtIiwicmVzdWx0IiwiaSIsIm5vZGVOYW1lIiwic3RhcnRJZnJhbWVUZXN0Il0sIm1hcHBpbmdzIjoidy9DQUFBOztBQUVBQSxNQUFNLENBQUUsWUFBVztBQUNsQjs7QUFFQSxNQUFJQyxJQUFJLEdBQUdELE1BQU0sQ0FBRSxpQ0FBRixDQUFqQjtBQUNBLE1BQUlFLE1BQU0sR0FBRyxFQUFiO0FBQ0EsTUFBSUMsQ0FBSixDQUxrQjtBQU1QRixFQUFBQSxJQU5PLGFBTWxCLG9EQUFrQixDQUFaRSxDQUFZO0FBQ2pCRCxNQUFBQSxNQUFNLElBQUlDLENBQUMsQ0FBQ0MsUUFBWjtBQUNBLEtBUmlCOztBQVVsQkMsRUFBQUEsZUFBZSxDQUFFSCxNQUFGLENBQWY7QUFDQSxDQVhLLENBQU4iLCJzb3VyY2VzQ29udGVudCI6WyIvKiBnbG9iYWwgc3RhcnRJZnJhbWVUZXN0ICovXG5cbmpRdWVyeSggZnVuY3Rpb24oKSB7XG5cdFwidXNlIHN0cmljdFwiO1xuXG5cdHZhciBlbGVtID0galF1ZXJ5KCBcIjxkaXY+PC9kaXY+PHNwYW4+PC9zcGFuPjxhPjwvYT5cIiApO1xuXHR2YXIgcmVzdWx0ID0gXCJcIjtcblx0dmFyIGk7XG5cdGZvciAoIGkgb2YgZWxlbSApIHtcblx0XHRyZXN1bHQgKz0gaS5ub2RlTmFtZTtcblx0fVxuXG5cdHN0YXJ0SWZyYW1lVGVzdCggcmVzdWx0ICk7XG59ICk7XG4iXX0=
