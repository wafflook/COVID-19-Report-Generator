const dict = {
  '04': 4,
  '03': 4,
  '06': 4
};

export default dict;
